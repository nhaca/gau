document.addEventListener('DOMContentLoaded', () => {

    // Khối Anti-DevTools được giữ nguyên
    (function antiDevToolsLight() {
        function stopSite() {
            document.body.innerHTML = `
            <div style="
                display:flex;
                justify-content:center;
                align-items:center;
                height:100vh;
                background:#0b0b0b;
                color:#ff4444;
                font-size:22px;
                font-weight:600;
                text-align:center;
            ">
                ⚠️ Truy cập bị hạn chế<br>
                Vui lòng đóng DevTools
            </div>
        `;
        }
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('keydown', e => {
            if (
                e.key === 'F12' ||
                (e.ctrlKey && e.shiftKey && ['i','j','c'].includes(e.key.toLowerCase())) ||
                (e.ctrlKey && e.key.toLowerCase() === 'u')
            ) {
                e.preventDefault();
                stopSite();
            }
        });
        setInterval(() => {
            const gapW = window.outerWidth - window.innerWidth;
            const gapH = window.outerHeight - window.innerHeight;
            if (gapW > 160 || gapH > 160) {
                stopSite();
            }
        }, 1500);
    })();

    // --- Theme Toggle --- (Giữ nguyên)
    const themeToggleBtn = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;

    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
        htmlElement.classList.add(currentTheme);
    } else {
        htmlElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    }

    themeToggleBtn.addEventListener('click', () => {
        if (htmlElement.classList.contains('dark')) {
            htmlElement.classList.remove('dark');
            htmlElement.classList.add('light');
            localStorage.setItem('theme', 'light');
            themeToggleBtn.innerHTML = '<i class="fas fa-moon w-5 h-5 text-indigo-600"></i>';
            themeToggleBtn.setAttribute('aria-label', 'Chuyển sang chế độ tối');
        } else {
            htmlElement.classList.remove('light');
            htmlElement.classList.add('dark');
            localStorage.setItem('theme', 'dark');
            themeToggleBtn.innerHTML = '<i class="fas fa-sun w-5 h-5 text-yellow-600"></i>';
            themeToggleBtn.setAttribute('aria-label', 'Chuyển sang chế độ sáng');
        }
    });

    if (htmlElement.classList.contains('dark')) {
        themeToggleBtn.innerHTML = '<i class="fas fa-sun w-5 h-5 text-yellow-600"></i>';
        themeToggleBtn.setAttribute('aria-label', 'Chuyển sang chế độ sáng');
    } else {
        themeToggleBtn.innerHTML = '<i class="fas fa-moon w-5 h-5 text-indigo-600"></i>';
        themeToggleBtn.setAttribute('aria-label', 'Chuyển sang chế độ tối');
    }

    // --- Announcement Banner --- (Giữ nguyên)
    const announcementBanner = document.getElementById('announcement-banner');
    const closeBannerBtn = document.getElementById('close-banner-btn');
    if (closeBannerBtn) {
        closeBannerBtn.addEventListener('click', () => {
            announcementBanner.style.display = 'none';
        });
    }

    // --- Dropdown Menus --- (Giữ nguyên)
    const dropdowns = document.querySelectorAll('.dropdown');
    dropdowns.forEach(dropdown => {
        const button = dropdown.querySelector('button');
        button.addEventListener('click', () => {
            dropdowns.forEach(otherDropdown => {
                if (otherDropdown !== dropdown) {
                    otherDropdown.classList.remove('active');
                }
            });
            dropdown.classList.toggle('active');
        });
        document.addEventListener('click', (event) => {
            if (!dropdown.contains(event.target)) {
                dropdown.classList.remove('active');
            }
        });
    });

    // --- Category Tabs Scrolling --- (Giữ nguyên)
    const categoryTabs = document.getElementById('category-tabs');
    const scrollLeftBtn = document.querySelector('.category-nav-wrapper .nav-scroll-btn.left-0');
    const scrollRightBtn = document.querySelector('.category-nav-wrapper .nav-scroll-btn.right-0');

    if (categoryTabs && scrollLeftBtn && scrollRightBtn) {
        scrollLeftBtn.addEventListener('click', () => {
            categoryTabs.scrollBy({ left: -200, behavior: 'smooth' });
        });
        scrollRightBtn.addEventListener('click', () => {
            categoryTabs.scrollBy({ left: 200, behavior: 'smooth' });
        });

        const allCategoryTabs = document.querySelectorAll('.category-tab');
        allCategoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                allCategoryTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                console.log('Category selected:', tab.textContent);
            });
        });

        const allSubcategoryTabs = document.querySelectorAll('.subcategory-tab');
        allSubcategoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                allSubcategoryTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                console.log('Subcategory selected:', tab.textContent);
            });
        });
    }

    // --- Modal Functionality (Chỉ giữ Login & Bind) ---
    const modals = document.querySelectorAll('.modal-overlay');
    const openLoginModalBtn = document.getElementById('open-login-modal-btn');
    const openBindAccountsModalBtn = document.getElementById('open-bind-accounts-modal-btn');
    const closeButtons = document.querySelectorAll('.modal-close-btn');

    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            modal.classList.add('visible');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeAllModals() {
        modals.forEach(modal => {
            modal.classList.remove('visible');
            // Chỉ thêm lại lớp 'hidden' cho các modal đang được giữ lại
            if (modal.id === 'login-modal' || modal.id === 'bind-accounts-modal') {
                modal.classList.add('hidden');
            }
        });
        document.body.style.overflow = '';
    }

    // Attach event listeners to open buttons
    if (openLoginModalBtn) openLoginModalBtn.addEventListener('click', (e) => { e.preventDefault(); closeAllModals(); openModal('login-modal'); });
    if (openBindAccountsModalBtn) openBindAccountsModalBtn.addEventListener('click', (e) => { e.preventDefault(); closeAllModals(); openModal('bind-accounts-modal'); });

    // Attach event listeners to close buttons
    closeButtons.forEach(button => {
        button.addEventListener('click', closeAllModals);
    });

    // Close modal when clicking outside of modal content
    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeAllModals();
            }
        });
    });

    // --- Login Modal Form Validation & Submission (Giữ nguyên) ---
    const loginForm = document.getElementById('login-form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('username-error');
    const passwordError = document.getElementById('password-error');
    const loginMessage = document.getElementById('login-message');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            let valid = true;
            usernameError.textContent = '';
            passwordError.textContent = '';
            loginMessage.textContent = '';
            loginMessage.classList.remove('success', 'error');

            if (usernameInput.value.trim() === '') {
                usernameError.textContent = 'Tài khoản không được để trống.';
                valid = false;
            }
            if (passwordInput.value.trim() === '') {
                passwordError.textContent = 'Mật khẩu không được để trống.';
                valid = false;
            }
            if (!valid) return;

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();
            const rememberMe = document.getElementById('remember-me').checked;

            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password, rememberMe })
                });
                const data = await response.json();

                if (data.success) {
                    loginMessage.textContent = 'Đăng nhập thành công! Đang chuyển hướng...';
                    loginMessage.classList.add('success');
                    setTimeout(() => {
                        closeAllModals();
                        if (data.role === 'admin') {
                            window.location.href = "/admin-dashboard";
                        } else {
                            window.location.href = "/user-dashboard";
                        }
                    }, 1500);
                } else {
                    loginMessage.textContent = `Đăng nhập thất bại: ${data.message || 'Sai tài khoản hoặc mật khẩu.'}`;
                    loginMessage.classList.add('error');
                }
            } catch (error) {
                console.error('Login error:', error);
                loginMessage.textContent = 'Đã xảy ra lỗi hệ thống. Vui lòng thử lại.';
                loginMessage.classList.add('error');
            }
        });
    }

    // === TOÀN BỘ LOGIC VIP PACKAGES & PAYMENT ĐÃ ĐƯỢC LOẠI BỎ ===

    // --- Bind Accounts Modal Logic (Giữ nguyên) ---
    const bindCards = document.querySelectorAll('.bind-card');
    bindCards.forEach(card => {
        const submitBtn = card.querySelector('.btn-primary');
        const platform = card.getAttribute('data-platform');

        if (submitBtn) {
            submitBtn.addEventListener('click', async () => {
                const idInput = card.querySelector(`#${platform.toLowerCase()}-id`);
                const nicknameInput = card.querySelector(`#${platform.toLowerCase()}-nickname`);

                if (!idInput) {
                    console.error(`ID input not found for platform: ${platform}`);
                    return;
                }

                const id = idInput.value.trim();
                const nickname = nicknameInput ? nicknameInput.value.trim() : '';

                if (!id) {
                    alert(`Vui lòng nhập ID cho ${platform}.`);
                    return;
                }

                try {
                    const response = await fetch('/api/accounts/bind', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ platform, id, nickname })
                    });
                    const data = await response.json();
                    if (data.success) {
                        alert(data.message || `Liên kết ${platform} thành công!`);
                    } else {
                        alert(`Liên kết ${platform} thất bại: ${data.message || 'Lỗi không xác định.'}`);
                    }
                } catch (error) {
                    console.error(`Error binding ${platform} account:`, error);
                    alert('Đã xảy ra lỗi khi liên kết tài khoản. Vui lòng thử lại.');
                }
            });
        }
    });

    // ===== LOGIC HIỂN THỊ MENU ĐĂNG NHẬP/ĐĂNG XUẤT (Giữ nguyên) =====
    fetch('/api/me')
        .then(r => r.json())
        .then(me => {

            const loginLink = document.getElementById('open-login-modal-btn');
            const logoutLink = document.getElementById('logout-link');
            const adminPanel = document.getElementById('admin-panel');

            if (me.logged_in) {
                if (loginLink) loginLink.classList.add('hidden');
                if (logoutLink) logoutLink.classList.remove('hidden');
            } else {
                if (loginLink) loginLink.classList.remove('hidden');
                if (logoutLink) logoutLink.classList.add('hidden');
            }

            // Logic Admin Panel (giữ lại để Admin có thể thấy)
            if (me.logged_in && me.role === 'admin') {
                if (adminPanel) {
                    adminPanel.style.display = 'block';
                    loadUsers();
                }
            }
        });

    // ===== LOAD USERS (Giữ nguyên) =====
    function loadUsers() {
        fetch('/api/admin/users')
            .then(res => res.json())
            .then(data => {
                if (!data.success) return;

                const tbody = document.getElementById('user-list');
                tbody.innerHTML = '';

                data.users.forEach(u => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                    <td>${u.username}</td>
                    <td>${u.password || '******'}</td>
                    <td>${u.role || 'user'}</td>
                `;
                    tbody.appendChild(tr);
                });
            });
    }
});