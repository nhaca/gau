from flask import Flask, request, jsonify, render_template, session, redirect
import json
import os

app = Flask(__name__)
# Đảm bảo bạn đã cài đặt biến môi trường cho secret key trong môi trường production thực tế.
app.secret_key = "phuc_dep_zai_secret_key"

USERS_FILE = "users.json"


# ================== UTIL ==================
def load_users():
    """Tải dữ liệu người dùng từ file JSON."""
    if not os.path.exists(USERS_FILE):
        return []
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        # Xử lý trường hợp file rỗng hoặc lỗi định dạng JSON
        return []


def save_users(users):
    """Lưu dữ liệu người dùng vào file JSON."""
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        # ensure_ascii=False để hỗ trợ tiếng Việt
        json.dump(users, f, ensure_ascii=False, indent=4)


def ensure_admin():
    """Đảm bảo tài khoản admin mặc định tồn tại."""
    users = load_users()
    if not any(u["role"] == "admin" for u in users):
        users.append({
            "username": "admin",
            "password": "adminphucdepzai@",
            "role": "admin"
        })
        save_users(users)


ensure_admin()


# ================== PAGES & REDIRECTS ==================

@app.route("/")
def home():
    """
    Trang chủ.
    - Nếu đã đăng nhập, chuyển hướng đến dashboard tương ứng.
    - Nếu chưa đăng nhập, trả về index.html.
    """
    role = session.get("role")
    if role == "admin":
        # Chuyển hướng Admin
        return redirect("/admin-dashboard")
    elif session.get("username"):
        # Chuyển hướng User thường
        return redirect("/user-dashboard")

    # Luôn trả về index.html nếu chưa đăng nhập
    return render_template("index.html")


@app.route("/user-dashboard")
def user_dashboard():
    """
    Dashboard cho người dùng thông thường (users.html).
    """
    if not session.get("username"):
        # Yêu cầu đăng nhập
        return redirect("/")

    if session.get("role") == "admin":
        # Ngăn admin vào trang user
        return redirect("/admin-dashboard")

    # Render file users.html trong thư mục templates/users
    return render_template("users/users.html")


@app.route("/admin-dashboard")
def admin_dashboard():
    """
    Dashboard cho Admin (admin.html).
    """
    # 🛑 Đây là kiểm tra bảo mật quan trọng:
    if session.get("role") != "admin":
        # Yêu cầu phải là admin, nếu không thì chuyển về trang chủ
        return redirect("/")

    # Render file admin.html trong thư mục templates/users
    return render_template("users/admin.html")


# ================== AUTH API ==================
@app.route("/api/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify(success=False, message="Thiếu thông tin đăng nhập")

    users = load_users()

    for u in users:
        if u["username"] == username and u["password"] == password:
            session["username"] = u["username"]
            # Lưu vai trò
            session["role"] = u.get("role", "user")
            # Trả về vai trò cho JavaScript xử lý chuyển hướng
            return jsonify(success=True, role=session["role"])

    return jsonify(success=False, message="Sai tài khoản hoặc mật khẩu")


@app.route("/logout")
def logout():
    session.clear() # 🧹 Session cũ sẽ được xóa ở đây!
    # Chuyển hướng về trang chủ sau khi đăng xuất
    return redirect("/")


@app.route("/api/me")
def me():
    return jsonify(
        logged_in=bool(session.get("username")),
        username=session.get("username"),
        role=session.get("role", "user")
    )


# ================== ADMIN API ==================
@app.route("/api/admin/users")
def admin_users():
    if session.get("role") != "admin":
        return jsonify(success=False, message="Forbidden"), 403

    # Trả về danh sách người dùng (chỉ username và role)
    # ⚠️ Không bao giờ trả về password!
    users = [{
        "username": u["username"],
        "role": u.get("role", "user")
    } for u in load_users()]

    return jsonify(success=True, users=users)


@app.route("/api/admin/create-user", methods=["POST"])
def create_user():
    if session.get("role") != "admin":
        return jsonify(success=False, message="Forbidden"), 403

    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    role = data.get("role", "user")

    if not username or not password:
        return jsonify(success=False, message="Thiếu username hoặc password")

    users = load_users()

    if any(u["username"] == username for u in users):
        return jsonify(success=False, message="Username đã tồn tại")

    users.append({
        "username": username,
        "password": password,
        "role": role
    })

    save_users(users)
    return jsonify(success=True)


# ================== RUN ==================
if __name__ == "__main__":
    app.run(debug=True)